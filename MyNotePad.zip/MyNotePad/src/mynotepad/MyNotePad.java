/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynotepad;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Adimin
 */
public class MyNotePad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JFrame note = new JFrame("My NotePad Assignment");
        note.setSize(700, 700);
        note.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar all = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenu edit = new JMenu("Edit");
        JMenu format = new JMenu("Format");
        JMenu about = new JMenu("About");

        JMenuItem nnew = new JMenuItem("New");
        JMenuItem open = new JMenuItem("Open");
        JMenuItem save = new JMenuItem("Save");
        JMenuItem saveas = new JMenuItem("Save-as");
        JMenuItem print = new JMenuItem("Print");
        JMenuItem exit = new JMenuItem("Exit");

        file.add(nnew);
        file.add(open);
        file.add(save);
        file.add(saveas);
        file.add(print);
        file.add(exit);

        JMenuItem undo = new JMenuItem("Undo");
        JMenuItem redo = new JMenuItem("Redo");
        JMenuItem cut = new JMenuItem("Cut");
        JMenuItem select = new JMenuItem("Select");
        JMenuItem Selectall = new JMenuItem("Select-All");
        JMenuItem paste = new JMenuItem("Paste");
        JMenuItem delete = new JMenuItem("Delete");
        JMenuItem date = new JMenuItem("Datw-Time");

        edit.add(undo);
        edit.add(redo);
        edit.add(cut);
        edit.add(select);
        edit.add(Selectall);
        edit.add(paste);
        edit.add(delete);
        edit.add(date);

        JMenuItem font = new JMenuItem("Font");
        format.add(font);

        JMenuItem abt = new JMenuItem("Develop-by");
        about.add(abt);

        all.add(file);
        all.add(edit);
        all.add(format);
        all.add(about);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        JTextArea txt = new JTextArea();
        JScrollPane sp = new JScrollPane();
        txt.add(sp);
        JScrollPane sbb = new JScrollPane(txt);

        txt.setMargin(new Insets(5, 5, 5, 5));

        note.add(all, BorderLayout.NORTH);
        note.add(txt);
        note.setVisible(true);
    }

}
