/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynotepad1;

/**
 *
 * @author Adimin
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.undo.UndoManager;

/**
 *
 * @author Adimin
 */
public class Mynotepad1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final JFrame note = new JFrame("My NotePad Assignment");
        note.setSize(700, 700);
        note.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar all = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenu edit = new JMenu("Edit");
        JMenu format = new JMenu("Format");
        JMenu about = new JMenu("About");

        JMenuItem nnew = new JMenuItem("New");

        JMenuItem open = new JMenuItem("Open");
        JMenuItem save = new JMenuItem("Save");
        JMenuItem saveas = new JMenuItem("Save-as");
        JMenuItem print = new JMenuItem("Print");
        JMenuItem exit = new JMenuItem("Exit");

        file.add(nnew);
        file.add(open);
        file.add(save);
        file.add(saveas);
        file.add(print);
        file.add(exit);

        JMenuItem undo = new JMenuItem("Undo");
        JMenuItem redo = new JMenuItem("Redo");
        JMenuItem copy = new JMenuItem("Copy");
        JMenuItem cut = new JMenuItem("Cut");
        JMenuItem select = new JMenuItem("Select");
        JMenuItem Selectall = new JMenuItem("Select-All");
        JMenuItem paste = new JMenuItem("Paste");
        JMenuItem delete = new JMenuItem("Delete");
        JMenuItem date = new JMenuItem("Date-Time");

        edit.add(undo);
        edit.add(redo);
        edit.add(copy);
        edit.add(cut);
        edit.add(select);
        edit.add(Selectall);
        edit.add(paste);
        edit.add(delete);
        edit.add(date);

        JMenuItem font = new JMenuItem("Font");
        format.add(font);

        JMenuItem abt = new JMenuItem("Develop-by");
        about.add(abt);

        all.add(file);
        all.add(edit);
        all.add(format);
        all.add(about);
        /////////////////////////file////////////////////////////////////////////////////////////////////////////
        final JTextArea txt = new JTextArea();
        JScrollPane sp = new JScrollPane();
        txt.add(sp);

        nnew.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText("");
            }
        });

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(note);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        FileReader fileReader = new FileReader(selectedFile);
                        BufferedReader bufferedReader = new BufferedReader(fileReader);
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;

                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }

                        bufferedReader.close();
                        txt.setText(stringBuilder.toString()); // Set the text in JTextArea
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }

        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showSaveDialog(note);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        FileWriter fileWriter = new FileWriter(selectedFile);
                        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                        bufferedWriter.write(txt.getText()); // Write the text from JTextArea to the file
                        bufferedWriter.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        saveas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showSaveDialog(note);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        FileWriter fileWriter = new FileWriter(selectedFile);
                        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                        bufferedWriter.write(txt.getText()); // Write the text from JTextArea to the file
                        bufferedWriter.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        print.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PrinterJob job = PrinterJob.getPrinterJob();
                if (job.printDialog()) {
                    job.setPrintable(new Printable() {
                        @Override
                        public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
                            if (pageIndex > 0) {
                                return Printable.NO_SUCH_PAGE;
                            }

                            Graphics2D g2d = (Graphics2D) graphics;
                            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

                            // You may need to adjust the font and size based on your requirements
                            Font font = new Font("Arial", Font.PLAIN, 12);
                            g2d.setFont(font);

                            String text = txt.getText();
                            String[] lines = text.split("\n");

                            int lineHeight = g2d.getFontMetrics().getHeight();
                            int y = 0;

                            for (String line : lines) {
                                y += lineHeight;
                                g2d.drawString(line, 0, y);
                            }

                            return Printable.PAGE_EXISTS;
                        }
                    });

                    try {
                        job.print();
                    } catch (PrinterException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.exit(0);
            }
        });
//////////////////////////////////////////edit////////////////////////////////////////////////////////////////////////////
        final UndoManager undoManager = new UndoManager();
        txt.getDocument().addUndoableEditListener(undoManager);
        
        
     undo.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (undoManager.canUndo()) {
                    undoManager.undo();
                }
    }
});

redo.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (undoManager.canRedo()) {
                    undoManager.redo();
                }
    }
});

           copy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

              txt.copy();
            }
        });
        cut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

              txt.cut();
            }
        });
        
          select.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

              txt.select(0, 0);
            }
        });
          Selectall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

              txt.selectAll();
            }
        });
            paste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

              txt.paste();
            }
        });
          
        delete.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int start = txt.getSelectionStart();
        int end = txt.getSelectionEnd();

        if (start != end) {
            txt.replaceRange("", start, end);
        }
    }
});

        
        
        
        
        abt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add code here to show information about the application
                JOptionPane.showMessageDialog(note, "My Notepad Application \n Version 1.0 \nDeveloped by Haile");
            }
        });
        note.add(all, BorderLayout.NORTH);
        note.add(txt);
        note.setVisible(true);
    }

}
